# SAT Solver Program
Run `python sat_solver.py` to start program.
Run with `-h` or `--help` option to view options.


# SAT Solver Program
Run `python main.py` to start program.
Run with `-h` or `--help` option to view options.


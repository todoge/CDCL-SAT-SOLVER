By Peh Jun Siang A0201838H, Sunaga Shion A0210635R

Our project 2 is based on Q1.

Section 6 of report has instructions to run the script and replicate our results.

We think that if we were the evaluator we should get an [A] due to the rigour of our project :D